
import java.util.Arrays;

public class Board {
    //private int[][] blocks;
    public int[][] blocks;
    private int N;
    private int manhattan;
    private static int[][] direction = {
                                        {-1, 0},
                                        {1, 0},
                                        {0, -1},
                                        {0, 1}
                                        };
    public Board(int[][] blocks) {
        // construct a board from an N-by-N array of blocks
        // (where blocks[i][j] = block in row i, column j)
        N = blocks.length;
        manhattan = -1;
        this.blocks = new int[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                this.blocks[i][j] = blocks[i][j];
            }
        }
    }
    public int dimension() {
        // board dimension N
        return N;
    }
    public int hamming() {
        // number of blocks out of place
        int misBlocks = 0;
        int k = 1;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (blocks[i][j] != k++)
                    misBlocks++;
            }
        }
        return --misBlocks;
    }
    public int manhattan() {
        // sum of Manhattan distances between blocks and goal
        if (manhattan == -1) {
            manhattan = 0;
            int k = 1;
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    if (blocks[i][j] != k++) {
                        if (blocks[i][j] != 0) {
                            int tmp = blocks[i][j] - 1;
                            manhattan += Math.abs(i - tmp / N) + Math.abs(j - tmp % N);
                        }
                    } 
                }
            }
        }
        return manhattan;
    }
    public boolean isGoal() {
        return manhattan() == 0; 
    }
    public Board twin() {
        // a board obtained by exchanging two adjacent blocks in the same row
        Board twinBoard = new Board(blocks);
        if (blocks[0][0] == 0 || blocks[0][1] == 0) {
            twinBoard.blocks[1][0] = blocks[1][1];
            twinBoard.blocks[1][1] = blocks[1][0];
        }
        else {
            twinBoard.blocks[0][0] = blocks[0][1];
            twinBoard.blocks[0][1] = blocks[0][0];
        }
        return twinBoard;
    }
    public boolean equals(Object y) {
        // does this board equal y?
        if (y == this) return true;
        if (y == null || y.getClass() != this.getClass()) return false;
        return Arrays.deepEquals(this.blocks, ((Board) y).blocks);
    }
    public Iterable<Board> neighbors() {
        // all neighboring boards
        Stack<Board> neighbors = new Stack<Board>();
        int i = 0, j = 0;
        L: for (i = 0; i < N; i++) {
            for (j = 0; j < N; j++) 
                if (blocks[i][j] == 0) break L;
        }
        for (int k = 0; k < direction.length; k++) {
            int x = i + direction[k][0];
            int y = j + direction[k][1];
            if (x < N && x >= 0 && y < N && y >= 0) {
                Board tmp = new Board(blocks);
                tmp.blocks[i][j] = tmp.blocks[x][y];
                tmp.blocks[x][y] = 0;
                neighbors.push(tmp);
            }
        }
        return neighbors;
    }
    public String toString() {
        // string representation of the board (in the output format specified below)
        StringBuilder s = new StringBuilder();
        s.append(N + "\n");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                s.append(String.format("%2d ", blocks[i][j]));
            }
            s.append("\n");
        }
        return s.toString();
    }
}
