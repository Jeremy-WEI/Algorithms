
//import java.util.HashSet;
//import java.util.Arrays;
public class Solver {
    private Stack<Board> solution; 
    private boolean isSolvable;
    private Node node1;
    private Node node2;
    private int moves = -1;
    private class Node implements Comparable<Node> {
        Board nodeBoard;
        Node prevNode;  
        int count;
        int priority;
        //int hashCode;
        public Node(Board board, int n, Node prev) {
            //hashCode = -1;
            nodeBoard = board;
            count = n;
            prevNode = prev;
            priority = count + board.manhattan();
        }
        public int compareTo(Node that) {
            if (priority < that.priority) return -1;
            if (priority == that.priority) return 0;
            return 1;
        }
        /*public int hashCode() {
            //return hashCode == -1 ? nodeBoard.toString().hashCode() : hashCode;
            if (hashCode == -1) {
                //hashCode = Arrays.deepHashCode(nodeBoard.blocks);
                hashCode = nodeBoard.toString().hashCode();
            }
            return hashCode;
        }*/
        public boolean equals(Object that) {
            if (that == this) return true;
            if (that == null) return false;
            if (that.getClass() != this.getClass()) return false;
            return nodeBoard.equals(((Node) that).nodeBoard);
        }
    }
    public Solver(Board initial) {    
        // find a solution to the initial board (using the A* algorithm)
        MinPQ<Node> pq = new MinPQ<Node>();
        MinPQ<Node> twinPq = new MinPQ<Node>();
        Board twinInitial = initial.twin();
        //HashSet<Node> set1 = new HashSet<Node>();
        //HashSet<Node> set2 = new HashSet<Node>();
        pq.insert(new Node(initial, 0, null));
        twinPq.insert(new Node(twinInitial, 0, null));
        while (true) {
            node1 = pq.delMin();
            node2 = twinPq.delMin();
            //set1.add(node1);
            //set2.add(node2);
            if (node1.nodeBoard.isGoal()) {
                solution = new Stack<Board>();
                isSolvable = true;
                moves = node1.count;
                do {
                    solution.push(node1.nodeBoard);
                    node1 = node1.prevNode;
                } while(node1 != null);
                break;
            }
            if (node2.nodeBoard.isGoal()) {
                isSolvable = false;
                break;
            }
            for (Board board: node1.nodeBoard.neighbors()) {
                Node tmp = new Node(board, node1.count + 1, node1);
                if (!tmp.equals(node1.prevNode))
                //if (!set1.contains(tmp)) {
                    pq.insert(tmp);
                //}
            }
            for (Board board: node2.nodeBoard.neighbors()) {
                Node tmp = new Node(board, node2.count + 1, node2);
                if (!tmp.equals(node2.prevNode))
                //if (!set2.contains(tmp)) {
                    twinPq.insert(tmp);
                //}
            }
        }
    }
    public boolean isSolvable() {
        // is the initial board solvable?
        return isSolvable;
    }
    public int moves() {
        // min number of moves to solve initial board; -1 if no solution
            return moves;
    }
    public Iterable<Board> solution() {
        // sequence of boards in a shortest solution; null if no solution
        return solution;
    }
    public static void main(String[] args) {
        // solve a slider puzzle (given below)
        Stopwatch watch = new Stopwatch();
        In in = new In(args[0]);
        int N = in.readInt();
        int[][] blocks = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);
        // solve the puzzle
        Solver solver = new Solver(initial);
        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
        StdOut.println(watch.elapsedTime());
    }
}
