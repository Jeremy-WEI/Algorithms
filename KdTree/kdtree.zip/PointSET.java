
import java.util.ArrayList;

public class PointSET {
    private SET<Point2D> pSet;
    public PointSET() {
        // construct an empty set of points
        pSet = new SET<Point2D>();
    }
    public boolean isEmpty() {
        // is the set empty?
        return pSet.isEmpty();
    }
    public int size() {
        // number of points in the set
        return pSet.size();
    }
    public void insert(Point2D p) {
        // add the point p to the set (if it is not already in the set)
        pSet.add(p);
    }
    public boolean contains(Point2D p) {
        // does the set contain the point p?
        return pSet.contains(p);
    }
    public void draw() {
        // draw all of the points to standard draw
        for (Point2D point : pSet) {
           point.draw();
        }
    }
    public Iterable<Point2D> range(RectHV rect) {
        // all points in the set that are inside the rectangle
        ArrayList<Point2D> points = new ArrayList<Point2D>();
        for (Point2D point : pSet) {
            if (rect.contains(point)) {
                points.add(point);
            }
        }
        return points;
    }
    public Point2D nearest(Point2D p) {
        // a nearest neighbor in the set to p; null if set is empty
        if (pSet.isEmpty()) return null;
        double minDistance2 = Double.MAX_VALUE;
        Point2D nearest = null; 
        for (Point2D point : pSet) {
            double tmp = point.distanceSquaredTo(p);
            if ( tmp < minDistance2) {
                nearest = point;
                minDistance2 = tmp;
            }
        }
        return nearest;
    }
}
