import java.util.Arrays;


public class Brute {
    public static void main(String[] args) {
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        In in = new In(args[0]);
        int num = in.readInt();
        Point[] pointArray = new Point[num];
        for (int i = 0; i < num; i++) {
            pointArray[i] = new Point(in.readInt(), in.readInt());
            pointArray[i].draw();
        }
        Arrays.sort(pointArray);
        for (int i = 0; i < pointArray.length - 3; i++) {
            for (int j = i + 1; j < pointArray.length - 2; j++) {
                double a = pointArray[i].slopeTo(pointArray[j]);
                for (int k = j + 1; k < pointArray.length - 1; k++) {
                    double b = pointArray[i].slopeTo(pointArray[k]);
                    if (a != b) continue;
                    for (int l = k + 1; l < pointArray.length; l++) {
                        if (a == pointArray[i].slopeTo(pointArray[l])) {
                            pointArray[i].drawTo(pointArray[l]);
                            StdOut.printf("%s -> %s -> %s -> %s\n" , 
                                pointArray[i].toString(), pointArray[j].toString(), 
                                    pointArray[k].toString(), pointArray[l].toString());
                        }
                    }
                }
            }
        }
    }
}