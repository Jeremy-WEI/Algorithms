
import java.util.Arrays;

public class Fast {
    public static void main(String[] args) {
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        In in = new In(args[0]);
        int num = in.readInt();
        Point[] pointArray = new Point[num];
        for (int i = 0; i < num; i++) {
            int a = in.readInt();
            int b = in.readInt();
            pointArray[i] = new Point(a, b);
            pointArray[i].draw();
        }
        StdDraw.show(0);
        Arrays.sort(pointArray);
        Point[] newPointArray = new Point[pointArray.length];
        for (int i = 0, j = 1; i < pointArray.length - 3; i++, j = 1) {
            newPointArray[0] = pointArray[i];
            for (; j <= i; j++) {
                newPointArray[j] = pointArray[j - 1];
            }
            for (; j < newPointArray.length; j++) {
                newPointArray[j] = pointArray[j];
            }
            Arrays.sort(newPointArray, 1, newPointArray.length, newPointArray[0].SLOPE_ORDER);
            int count = 1;
            Point p = newPointArray[0];
            L: for (j = 1; j < newPointArray.length - 1; j++, count = 1) {
                double a = p.slopeTo(newPointArray[j]);
                double b = p.compareTo(newPointArray[j]);
                if (b > 0) {
                    if (a == Double.POSITIVE_INFINITY) break L;
                    while (j < newPointArray.length - 1 && a 
                            == p.slopeTo(newPointArray[j + 1])) {
                        j++; 
                    }
                    continue;
                }
                if (a == Double.POSITIVE_INFINITY) {
                    if (j < newPointArray.length - 2) {
                        p.drawTo(newPointArray[newPointArray.length - 1]);
                        StdOut.print(p.toString());
                        for (; j < newPointArray.length; j++) {
                            StdOut.printf(" -> %s", newPointArray[j].toString());
                        }
                        StdOut.println();
                    }
                    break L;
                }
                while (j < newPointArray.length - 1 && a == p.slopeTo(newPointArray[j + 1])) {
                    count++;
                    j++;
                }
                if (count >= 3) {
                    p.drawTo(newPointArray[j]);
                    StdOut.print(p.toString());
                    for (int k = j - count + 1; k <= j; k++) {
                        StdOut.printf(" -> %s", newPointArray[k].toString());
                    }
                    StdOut.println();
                }
            }
            StdDraw.show(0);
        }
    }
}         
                    
                    
                    
                    
                    
                    
                       