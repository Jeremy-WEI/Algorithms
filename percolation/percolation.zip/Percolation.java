
public class Percolation {
    private WeightedQuickUnionUF wquuf1;
    private WeightedQuickUnionUF wquuf2;
    private boolean[] stateOfGrid;
    private int num;
    public Percolation(int N) {
        num = N;
        wquuf1 = new WeightedQuickUnionUF(N * N + 2);
        wquuf2 = new WeightedQuickUnionUF(N * N + 2);
        stateOfGrid = new boolean[N * N + 2];
        for (int i = 1, last = N * N + 1; i <= N; i++) {
            wquuf1.union(0, i);
            wquuf2.union(0, i);
            wquuf1.union(last, last - i);
        }
    }
    public void open(int i, int j) {
        if (i < 1 || i > num || j < 1 || j > num) 
            throw new IndexOutOfBoundsException("row index i out of bounds");
        int tmp = (i - 1) * num + j;
        if (!stateOfGrid[tmp]) {
            stateOfGrid[tmp] = true;
            if (j > 1 && stateOfGrid[tmp - 1]) {
                wquuf1.union(tmp - 1, tmp);
                wquuf2.union(tmp - 1, tmp);
            }
            if (j < num && stateOfGrid[tmp + 1]) {
                wquuf1.union(tmp + 1, tmp);
                wquuf2.union(tmp + 1, tmp);
            }
            if (i > 1 && stateOfGrid[tmp - num]) {
                wquuf1.union(tmp - num, tmp);
                wquuf2.union(tmp - num, tmp);
            }
            if (i < num && stateOfGrid[tmp + num]) {
                wquuf1.union(tmp + num, tmp);
                wquuf2.union(tmp + num, tmp);
            }
        }
    }
    public boolean isOpen(int i, int j) {
        if (i < 1 || i > num || j < 1 || j > num) 
            throw new IndexOutOfBoundsException("row index i out of bounds");
        return stateOfGrid[(i - 1) * num + j];
    }
    public boolean isFull(int i, int j) {
        if (i < 1 || i > num || j < 1 || j > num) 
            throw new IndexOutOfBoundsException("row index i out of bounds");
        int tmp = (i - 1) * num + j;
        return stateOfGrid[tmp] && wquuf2.connected(0, tmp);
    }
    public boolean percolates() {
        if (num == 1) return isOpen(1, 1);
        return wquuf1.connected(0, num * num + 1);
    }
}
