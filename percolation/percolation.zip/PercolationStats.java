
public class PercolationStats {
    private int numOfGrid;
    private int countTest;
    private double[] x;
    public PercolationStats(int N, int T) {
        if (N <= 0 || T <= 0) 
            throw new IllegalArgumentException();
        numOfGrid = N * N;
        countTest = T;
        x = new double[T];
        for (int i = 0; i < T; i++) {
            int countOpen = 0;
            Percolation perc = new Percolation(N);
            while (!perc.percolates()) {
                int j = StdRandom.uniform(1, N + 1);
                int k = StdRandom.uniform(1, N + 1);
                if (!perc.isOpen(j, k)) {
                    perc.open(j, k);
                    countOpen++;
                }
            }
            x[i] = (double) countOpen / numOfGrid;
        }
    }
    public double mean() {
        return StdStats.mean(x);
    }
    public double stddev() {
        return StdStats.stddev(x);
    }
    public double confidenceLo() {
        return mean() - 1.96 * stddev() / Math.sqrt(countTest);
    }
    public double confidenceHi() {
        return mean() + 1.96 * stddev() / Math.sqrt(countTest);
    }
    public static void main(String[] args) {
        PercolationStats test = new PercolationStats(1, 1);
        StdOut.println("mean = " + test.mean());
        StdOut.println("stddev = " + test.stddev());
        StdOut.println("95% confidence interval = " + test.confidenceLo() + " , " + test.confidenceHi());
    }
}
